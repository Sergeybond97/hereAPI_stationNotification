var directName;
var posDirect;

var myPosName
var posMy{...};

