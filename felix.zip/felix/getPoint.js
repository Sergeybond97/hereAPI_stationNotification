function input()
{
	directName = document.getElementById('PointGetter').value;
	output(directName);
}

var geocoder = platform.getGeocodingService();
var onResult = function(result) 
{
  var locations = result.Response.View[0].Result,
				  position,
				  marker;
  for (i = 0;  i < locations.length; i++) {
  position = {
    lat: locations[i].Location.DisplayPosition.Latitude,
    lng: locations[i].Location.DisplayPosition.Longitude
  };
  marker = new H.map.Marker(position);
  map.addObject(marker);
  }
};

function output(addr)
{
	var geocodingParams = {
    searchText: addr
  };
  
geocoder.geocode(geocodingParams, onResult, function(e) {
	//alert(e);
	});
}

function onSuccess(result) 
{
  posDirect = result.Response.View[0].Result[0].Place.Locations[0];
};

geocoder.search({searchText: directName}, onSuccess, function(e) {
  alert(e);
});




